import tkinter as tk
from tkinter import messagebox

# ดิกชันนารีเก็บบาร์โค้ดและราคา
barcode_data = {
    "123456789012": 50.0,
    "987654321098": 75.5,
    "111222333444": 100.0,
}

def check_price():
    barcode = entry.get()
    if barcode in barcode_data:
        price = barcode_data[barcode]
        result_label.config(text=f"ราคา: {price} บาท")
    else:
        messagebox.showerror("ไม่พบข้อมูล", "บาร์โค้ดนี้ไม่มีในระบบ")

def add_barcode():
    new_barcode = new_barcode_entry.get()
    new_price = new_price_entry.get()
    
    if new_barcode and new_price:
        try:
            barcode_data[new_barcode] = float(new_price)
            messagebox.showinfo("สำเร็จ", "เพิ่มบาร์โค้ดใหม่เรียบร้อย")
            new_barcode_entry.delete(0, tk.END)
            new_price_entry.delete(0, tk.END)
        except ValueError:
            messagebox.showerror("ข้อผิดพลาด", "กรุณากรอกราคาเป็นตัวเลข")
    else:
        messagebox.showerror("ข้อผิดพลาด", "กรุณากรอกข้อมูลให้ครบ")

# สร้าง GUI
root = tk.Tk()
root.title("แอปตรวจสอบบาร์โค้ด")
root.geometry("300x300")

tk.Label(root, text="กรอกเลขบาร์โค้ด:").pack(pady=5)
entry = tk.Entry(root)
entry.pack(pady=5)

tk.Button(root, text="ตรวจสอบ", command=check_price).pack(pady=5)

result_label = tk.Label(root, text="")
result_label.pack(pady=5)

# ส่วนเพิ่มบาร์โค้ดใหม่
tk.Label(root, text="เพิ่มบาร์โค้ดใหม่:").pack(pady=5)
new_barcode_entry = tk.Entry(root)
new_barcode_entry.pack(pady=5)

tk.Label(root, text="ตั้งราคา:").pack(pady=5)
new_price_entry = tk.Entry(root)
new_price_entry.pack(pady=5)

tk.Button(root, text="เพิ่มบาร์โค้ด", command=add_barcode).pack(pady=5)

root.mainloop()
